import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cheques',
  templateUrl: './cheques.component.html',
  styleUrls: ['./cheques.component.css']
})
export class ChequesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
