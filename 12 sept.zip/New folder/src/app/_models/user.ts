export class User {
    
    first_name: string;
    last_name: string;
    email:string;
    username: string;
    password:string;
    confirmPassword:string;
    address:string;
    city:string;
    pinCode:string;
    state:string;
    aadhaarNumber:string;
    phone_number:string;
}