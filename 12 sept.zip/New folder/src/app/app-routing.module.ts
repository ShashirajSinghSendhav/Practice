import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { WebsiteComponent } from './website/website.component';
import { UserComponent } from './user/user.component';

import { AuthGuard } from './auth.guard';
import { AdminComponent } from './layouts/admin/admin.component';
import { AddMoneyComponent } from './layouts/user_menu/add-money/add-money.component';
import { AddAdminComponent } from './layouts/admin_dashboard/add-admin/add-admin.component';
import { CustomersComponent } from './layouts/admin_dashboard/customers/customers.component';
import { SettingsComponent } from './layouts/user_menu/settings/settings.component';
import { AccountSummaryComponent } from './layouts/user_menu/account-summary/account-summary.component';
import { ChequesComponent } from './layouts/user_menu/cheques/cheques.component';
import { DashboardComponent } from './layouts/user_menu/dashboard/dashboard.component';
import { SendMoneyComponent } from './layouts/user_menu/send-money/send-money.component';
import { ViewPassbookComponent } from './layouts/user_menu/view-passbook/view-passbook.component';


const routes: Routes = [
  { path: '', pathMatch:"full", component: WebsiteComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'user', component: UserComponent },
  { path: 'admin', component: AdminComponent },
  //canActivate: [AuthGuard] 

  //admin routes
  { path: 'add_money', component:AddMoneyComponent},
  { path: 'add_admin', component:AddAdminComponent},
  { path: 'customers', component:CustomersComponent},
  { path: 'settings', component:SettingsComponent},

  //user routes through dashboard

  { path: 'account_summary', component:AccountSummaryComponent},
  { path: 'add_money', component:AddMoneyComponent},
  { path: 'cheques', component:ChequesComponent},
  { path: 'dashboard', component:DashboardComponent},
  { path: 'send-money', component:SendMoneyComponent},
  { path: 'view_passbook', component:ViewPassbookComponent},

  { path: '**', redirectTo: 'website' }
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
